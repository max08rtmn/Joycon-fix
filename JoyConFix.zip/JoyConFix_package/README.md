# JoyConFix.dylib
**Single JoyCon horizontal mode fix for LiveContainer**

## Was dieser Tweak behebt
- ✅ Stick wird nicht mehr als D-Pad erkannt
- ✅ 90°-Rotation des Sticks für horizontale Haltung korrigiert
- ✅ Verhindert dass alle 4 Buttons gleichzeitig ausgelöst werden
- ✅ Schulterknöpfe (SL/SR) werden korrekt erkannt
- ✅ Erzwingt `extendedGamepad`-Profil statt `microGamepad`

## Ursache des Problems
Im Einzel-Modus sendet ein JoyCon andere HID-Reports als im Paar-Modus:
- Der Stick wird als D-Pad-Input fehlinterpretiert (microGamepad-Profil)
- Die Achsen sind um 90° gedreht (horizontale Haltung)
- Button-Bits überlappen im HID-Report → alle 4 Buttons gleichzeitig

## Installation in LiveContainer
1. Dylib bauen (siehe unten)
2. `JoyConFix.dylib` in den LiveContainer Tweak-Ordner kopieren:
   - Pfad: `LiveContainer/Tweaks/JoyConFix.dylib`
3. App neu starten

## Dylib selbst bauen (macOS + Xcode nötig)
```bash
chmod +x build.sh
./build.sh
```

Oder mit Theos:
```bash
make ARCHS="arm64 arm64e" TARGET="iphone:clang:16.5:14.0"
```

## Debugging
Logs erscheinen in der Konsole mit dem Prefix `[JoyConFix]`:
```
[JoyConFix] v1.0 loaded — Single JoyCon fix active
[JoyConFix] Swizzles installed successfully
[JoyConFix] Stick corrected (0.00,1.00)→(1.00,-0.00)
```
