#!/bin/bash
# Build JoyConFix.dylib for iOS (arm64 + arm64e)
# Run this on a macOS machine with Xcode installed

SDK=$(xcrun --sdk iphoneos --show-sdk-path 2>/dev/null)
if [ -z "$SDK" ]; then
    echo "ERROR: Xcode iOS SDK not found. Run this on macOS with Xcode installed."
    exit 1
fi

clang \
    -arch arm64 \
    -arch arm64e \
    -dynamiclib \
    -fobjc-arc \
    -isysroot "$SDK" \
    -mios-version-min=14.0 \
    -framework GameController \
    -framework Foundation \
    -install_name /usr/lib/JoyConFix.dylib \
    -o JoyConFix.dylib \
    joycon_fix_standalone.m

if [ $? -eq 0 ]; then
    echo "✅ JoyConFix.dylib built successfully"
    file JoyConFix.dylib
    otool -L JoyConFix.dylib
else
    echo "❌ Build failed"
fi
